package com.example.hp.colorchange;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3,b4;
    EditText t;
    String clr[];
    Drawable defaultColor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button7);
        b4=(Button)findViewById(R.id.button8);
        t=(EditText)findViewById(R.id.editText);
        defaultColor = b1.getBackground();

        t.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                clr = t.getText().toString().toLowerCase().split(",");
                boolean r = false, g = false, b = false, y = false;
                for (String text : clr) {
                    if (text.matches("(red|green|blue|yellow)")) {
                        if (text.contains("red")) {

                            b1.setBackgroundColor(Color.RED);
                            r = true;

                        }
                        if (text.contains("yellow")) {
                            b2.setBackgroundColor(Color.YELLOW);
                            y = true;

                        }
                        if (text.contains("blue")) {

                            b3.setBackgroundColor(Color.BLUE);
                            b = true;

                        }
                        if (text.contains("green")) {

                            b4.setBackgroundColor(Color.GREEN);
                            g = true;

                        }
                    }
                    if (!b)
                        b3.setBackground(defaultColor);
                    if (!r)
                        b1.setBackground(defaultColor);
                    if (!g)
                        b4.setBackground(defaultColor);
                    if (!y)
                        b2.setBackground(defaultColor);

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}
