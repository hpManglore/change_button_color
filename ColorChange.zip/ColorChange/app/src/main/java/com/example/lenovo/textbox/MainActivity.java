package com.example.lenovo.textbox;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button b1;
    Button b2;
    Button b3;
    Button b4;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText text=(EditText)findViewById(R.id.EtText);
        b1=(Button)findViewById(R.id.btn1);
        b2=(Button)findViewById(R.id.btn2);
        b3=(Button)findViewById(R.id.btn3);
        b4=(Button)findViewById(R.id.btn4);



        text.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                String c=s.toString().toUpperCase();
                String ss[]=c.split(",");
                boolean r=false,g=false,b=false,blk=false;
                for(String check:ss)
                {
                    if(check.equals(("RED"))) {
                        b1.setBackgroundColor(Color.RED);
                        r = true;
                    }
                    if(check.equals(("GREEN"))) {
                        b2.setBackgroundColor(Color.GREEN);
                        g = true;
                    }
                    if(check.equals(("BLUE"))) {
                        b3.setBackgroundColor(Color.BLUE);
                        b = true;
                    }
                    if(check.equals(("GRAY"))) {
                        b4.setBackgroundColor(Color.GRAY);
                        blk = true;
                    }
                    if(!r)
                        b1.setBackgroundColor(Color.LTGRAY);
                    if(!g)
                        b2.setBackgroundColor(Color.LTGRAY);
                    if(!b)
                        b3.setBackgroundColor(Color.LTGRAY);
                    if(!blk)
                        b4.setBackgroundColor(Color.LTGRAY);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}
