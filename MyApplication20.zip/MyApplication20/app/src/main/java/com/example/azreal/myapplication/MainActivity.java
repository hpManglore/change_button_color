package com.example.azreal.myapplication;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button b1, b2, b3, b4, b5, b6;
    EditText e1;
    String s[];
    Drawable defaultColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button) findViewById(R.id.button);
        b2 = (Button) findViewById(R.id.button2);
        b3 = (Button) findViewById(R.id.button3);
        b4 = (Button) findViewById(R.id.button4);
        b5 = (Button) findViewById(R.id.button5);
        b6 = (Button) findViewById(R.id.button6);
        e1 = (EditText) findViewById(R.id.editText);
        defaultColor=b1.getBackground();

        e1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {


                s= e1.getText().toString().toLowerCase().split(",");
                boolean r=false,g=false,b=false,y=false,bl=false,w=false;

                for(String text:s)
                {
                    if(text.matches("" + "(red|blue|green|yellow|black|white)")) {
                        if (text.contains("red")) {
                            b1.setBackgroundColor(Color.RED);
                            r=true;
                        }
                        if (text.contains("blue")) {
                            b2.setBackgroundColor(Color.BLUE);
                            b=true;
                        }
                        if (text.contains("green")) {
                            b4.setBackgroundColor(Color.GREEN);
                            g=true;
                        }
                        if (text.contains("yellow")) {
                            b3.setBackgroundColor(Color.YELLOW);
                            y=true;

                        }
                        if (text.contains("black")) {
                            b5.setBackgroundColor(Color.BLACK);
                            bl=true;
                        }
                        if (text.contains("white")) {
                            b6.setBackgroundColor(Color.WHITE);
                            w=true;
                        }
                    }



                    if(!b)
                        b2.setBackground(defaultColor);
                    if(!r)
                        b1.setBackground(defaultColor);
                    if(!g)
                        b4.setBackground(defaultColor);
                    if(!y)
                        b3.setBackground(defaultColor);
                    if(!bl)
                        b5.setBackground(defaultColor);
                    if(!w)
                        b6.setBackground(defaultColor);

                }

                }




            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }
}
