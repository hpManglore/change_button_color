package com.example.vikrant.color;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3,b4;
    EditText t;
    String s[];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
        b4=(Button)findViewById(R.id.button4);
        t=(EditText)findViewById(R.id.editText);
        t.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                s = t.getText().toString().split(",");
                for (String text : s) {


                    if (text.contains("green")) {
                        b1.setBackgroundColor(Color.GREEN);
                    }
                    if (text.contains("red")) {
                        b2.setBackgroundColor(Color.RED);
                    }
                    if (text.contains("blue")) {
                        b3.setBackgroundColor(Color.BLUE);
                    }
                    if (text.contains("yellow")) {
                        b4.setBackgroundColor(Color.YELLOW);
                    }
                    if(text.contains(" "))
                    {
                        b1.setBackgroundColor(Color.GRAY);
                        b2.setBackgroundColor(Color.GRAY);
                        b3.setBackgroundColor(Color.GRAY);
                        b4.setBackgroundColor(Color.GRAY);

                    }

                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }
}
