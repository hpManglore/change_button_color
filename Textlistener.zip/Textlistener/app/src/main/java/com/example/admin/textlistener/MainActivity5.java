package com.example.admin.textlistener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.*;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity5 extends AppCompatActivity {
EditText et1;
Button b1,b2,b3;//b4,b5,b6,b7,b8;
TextView tt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        et1=(EditText)findViewById(R.id.editText);
        b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
       /* b4=(Button)findViewById(R.id.button4);
        b5=(Button)findViewById(R.id.button5);
        b6=(Button)findViewById(R.id.button6);
        b7=(Button)findViewById(R.id.button7);
        b8=(Button)findViewById(R.id.button8);*/
        tt=findViewById(R.id.t1);
        et1.addTextChangedListener(new TextWatcher() {

            int i=0;
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

              /*  String str=et1.getText().toString();




                if(str.matches("RED|GREEN|BLUE"))
                {

                    boolean r=false,b=false,g=false;
                   tt.setText(tt.getText().toString()+str);
                    if(str.contentEquals("RED"))
                    {
                        b1.setBackgroundColor(Color.RED);
                        r=true;
                    }

                    else if(str.contentEquals("GREEN"))
                    {
                        b3.setBackgroundColor(Color.GREEN);
                        g=true;
                    }

                   else if(str.contentEquals("BLUE"))
                    {
                        b2.setBackgroundColor(Color.BLUE);
                        b=true;
                    }
                    if(r==false)
                    {
                        b1.setBackgroundColor(Color.RED);
                    }

                }

               // String[] sep=str.split(",");
               /* for(int i=0;i<sep.length;i++){
                    if(sep[i].equals("red"))
                    {
                        b1.setBackgroundColor(Color.RED);
                    }
                    else
                        if(sep[i].equals("blue"))
                    {
                        b2.setBackgroundColor(Color.BLUE);
                    }
                        else
                        if(sep[i].equals("green"))
                        {
                            b3.setBackgroundColor(Color.GREEN);
                        }
                        else
                        if(sep[i].equals("black"))
                        {
                            b4.setBackgroundColor(Color.BLACK);
                        }
                        else
                        if(sep[i].equals("yellow"))
                        {
                            b5.setBackgroundColor(Color.YELLOW);
                        }
                        else
                        if(sep[i].equals("gray"))
                        {
                            b6.setBackgroundColor(Color.GRAY);
                        }
                        else
                        if(sep[i].equals("magenta"))
                        {
                            b7.setBackgroundColor(Color.MAGENTA);
                        }
                        else
                        if(sep[i].equals("cyan"))
                        {
                            b2.setBackgroundColor(Color.CYAN);
                        }
                }*/
            }

            @Override
            public void afterTextChanged(Editable s) {
                /*String s1="red,green,blue,white,black,grey,cyan,pink,orange,yellow";
                String[] s3=s1.split("\\,");
                for(int i=0;i<s3.length;i++) {
                    if ((et1.toString().trim().length()) > 0) {
                        if (et1.getText().toString() == s3[i]) {
                            b1.setBackgroundColor(Color.parseColor(s3[i]));
                        }
                    }
                }*/

               /* ArrayList<String> arrayList=new ArrayList<String>(Arrays.asList("red,green,blue,white,black,grey,cyan,pink,orange,yellow"));
                for(int i=0;i<arrayList.size();i++)
                if(et1.getText().toString()==arrayList.get(i)){
                   b1.setBackgroundColor(Color.parseColor(arrayList.get(i)));
                }
               /*

                    String s2= s1.substring(0);
                   if ((et1.toString().contentEquals(s2)))
                    {

                    b1.setBackgroundColor(et1.getCurrentTextColor());
                }

            }*/

                String[] str=et1.getText().toString().split(",");

                boolean r=false,b=false,g=false;



                // tt.setText(str[]);
                //String str2 = str.toString();
                for(int i=0;i<str.length;i++)
                {
                    if((str[i].matches("red|green|blue")))
                    {
                        if(str[i].contentEquals("red"))
                        {
                            b1.setBackgroundColor(Color.RED);
                            r=true;
                        }


                        if(str[i].contentEquals("green"))
                        {
                            b3.setBackgroundColor(Color.GREEN);
                            g=true;
                        }


                        if(str[i].contentEquals("blue"))
                        {
                            b2.setBackgroundColor(Color.BLUE);
                            b=true;
                        }


                        if(r==true)
                        {
                            b1.setBackgroundColor(Color.RED);
                        }
                        else
                        {

                            b1.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(b==true)
                        {
                            b2.setBackgroundColor(Color.BLUE);
                        }
                        else
                        {

                            b2.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(g==true)
                        {
                            b3.setBackgroundColor(Color.GREEN);
                        }
                        else{

                            b3.setBackgroundResource(android.R.drawable.btn_default);
                        }


                    }
                    else{
                        if(r==false)
                        {
                            b1.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(g==false)
                        {
                            b3.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(b==false)
                        {
                            b2.setBackgroundResource(android.R.drawable.btn_default);
                        }
                    }
                }

            }
        });
    }

}
